module.exports = (client) => {
  console.log(`Bağlantı Koptu! ${new Date()}`);
};
