module.exports = client => {
  console.log(`Başlatılıyor... ${new Date()}`);
};