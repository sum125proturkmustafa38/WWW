const {MessageEmbed} = require('discord.js');

exports.run = (client, message, args) => {
    let mesaj = args.slice(0).join(' ');
    const embed = new MessageEmbed()
    .setAuthor('')
    .setColor("BLUE")
    .setDescription(`** ${mesaj} ` + message.author.username + ' FBI Baskını!**')
    .setImage(`https://media1.tenor.com/images/93d11bc59526ce49f60766f0045d819b/tenor.gif?itemid=11500735`)
    return message.channel.send({embeds: [embed]});
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['fbi','Fbi','FBİ',],
  permLevel: 0
};

exports.help = {
  name: 'fbi',
  description: 'fbi',
  usage: 'fbi',
};